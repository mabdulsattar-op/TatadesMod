package com.tatadesmod.module.impl;

import com.tatadesmod.config.ConfigManager;
import com.tatadesmod.module.Module;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

public class AutoClickerModule extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final Random random = new Random();

    // settings
    private boolean holdOnly = true;
    private int button = GLFW.GLFW_MOUSE_BUTTON_LEFT; // 0 left, 1 right
    private int minCps = 8;
    private int maxCps = 12;
    private boolean randomize = true;
    private boolean smallDeviation = true;

    private long nextClickAt = 0L;
    private boolean pressing = false;

    public AutoClickerModule() {
        super("AutoClicker", Category.COMBAT);
    }

    @Override
    protected void onEnable() {
        // load settings from config if present
        Object v;
        ConfigManager.ConfigData cd = ConfigManager.get();
        v = cd.values.getOrDefault("autoclicker.minCps", minCps);
        minCps = ((Number) v).intValue();
        v = cd.values.getOrDefault("autoclicker.maxCps", maxCps);
        maxCps = ((Number) v).intValue();

        ClientTickEvents.END_CLIENT_TICK.register(this::tickEvent);
    }

    @Override
    protected void onDisable() {
        // nothing special
    }

    private void tickEvent(MinecraftClient client) {
        // left/right mouse state
        boolean mouseDown = false;
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) mouseDown = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == 1;
        else mouseDown = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == 1;

        if (mc.currentScreen != null) return; // do not click in GUI

        if (holdOnly && !mouseDown) {
            pressing = false;
            return;
        }

        long now = System.currentTimeMillis();
        if (now >= nextClickAt) {
            // compute CPS
            int cps = minCps;
            if (maxCps > minCps) {
                if (randomize) cps = minCps + random.nextInt(maxCps - minCps + 1);
                else cps = minCps;
            }
            double intervalMs = 1000.0 / cps;
            if (smallDeviation) intervalMs *= 0.9 + (random.nextDouble() * 0.2);
            nextClickAt = now + (long)Math.max(1, Math.round(intervalMs));

            // perform click
            if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
                mc.mouse.click(InputUtil.Type.MOUSE, 0, true); // this is a client-side convenience call
                mc.player.swingHand(mc.player.getActiveHand());
            } else {
                mc.mouse.click(InputUtil.Type.MOUSE, 1, true);
            }
        }
    }

    @Override
    public void tick() { /* module ticked by ModuleManager as well */ }

    // setters/getters for GUI binding
    public int getMinCps() { return minCps; }
    public int getMaxCps() { return maxCps; }
    public void setMinCps(int v) { minCps = v; ConfigManager.get().values.put("autoclicker.minCps", v); ConfigManager.save(); }
    public void setMaxCps(int v) { maxCps = v; ConfigManager.get().values.put("autoclicker.maxCps", v); ConfigManager.save(); }
    public boolean isRandomize() { return randomize; }
    public void setRandomize(boolean r) { randomize = r; ConfigManager.get().values.put("autoclicker.randomize", r); ConfigManager.save(); }
}
